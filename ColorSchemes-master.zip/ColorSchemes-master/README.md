# ColorSchemes
- Some color schemes for IDE.
- 用过这么多IDE，个人还是觉得Xcode的配色最好看，所以给JetBrains系列的IDE都做了一套仿Xcode的配色方案
	- **CLion_MJ.jar**：[CLion](https://www.jetbrains.com/clion/)
	- **IDEA_MJ.jar**：[IntelliJ IDEA](https://www.jetbrains.com/idea/)




## 配色示例
![](https://img2020.cnblogs.com/blog/497279/202004/497279-20200402230501047-1091095060.png)

![](https://img2020.cnblogs.com/blog/497279/202004/497279-20200402231327691-1056514738.png)




## 导入步骤
![](https://img2020.cnblogs.com/blog/497279/202004/497279-20200402230510743-789637455.png)

![](https://img2020.cnblogs.com/blog/497279/202004/497279-20200402230514824-268457947.png)
